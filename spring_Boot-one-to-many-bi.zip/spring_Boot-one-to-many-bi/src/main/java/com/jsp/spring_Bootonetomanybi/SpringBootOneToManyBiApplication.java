package com.jsp.spring_Bootonetomanybi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOneToManyBiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOneToManyBiApplication.class, args);
	}

}
