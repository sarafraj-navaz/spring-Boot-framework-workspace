package com.jsp.medishop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedishopApplicationTests {

	@Test
	void contextLoads() {
	}

}
