package com.jsp.medishop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedishopApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedishopApplication.class, args);
	}

}
