package com.jsp.spring_Bootmanytomanybi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootManyToManyBiApplicationTests {

	@Test
	void contextLoads() {
	}

}
